package br.com.herbertrausch.spring.mongo;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.util.Assert;

@Document
public class RegistroFinanceiro {
	
	private float valor;
	private String data, dataRegistro;
	
	@DBRef
	private Usuario usuario;

	public float getValor() {
		return valor;
	}

	public void setValor(float valor) {
		this.valor = valor;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}
	
	public String getDataRegistro() {
		return dataRegistro;
	}

	public void setDataRegistro(String dataRegistro) {
		this.dataRegistro = dataRegistro;
	}
	
	public Usuario getUsuario(){
		return usuario;
	}
	
	public void SetUsuario(Usuario usuario){
		this.usuario = usuario;
	}
	
	
}
