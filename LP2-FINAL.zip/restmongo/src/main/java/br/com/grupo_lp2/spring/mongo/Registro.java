package br.com.lp2.spring.mongo;

import java.io.Serializable;

import org.springframework.data.mongodb.core.mapping.Document;


@Document
public class Registro implements Serializable{

	private static final long serialVersionUID = 1L;

	private int tipo;
	private String dataArrecadacao;
	private String dataRegistro;
	private String validade;
	private int quantidade;
	private Usuario idUsuario;
	private Produto idProduto;
	private Membro idMembro;
	
	public int getTipo(){return tipo;}
	public void setTipo(int tipo){this.tipo = tipo;}
	
	public String getDataArrecadacao(){return dataArrecadacao;}
	public void setDataArrecadacao(String dataArrecadacao){this.dataArrecadacao = dataArrecadacao;}
	
	public String getDataRegistro(){return dataRegistro;}
	public void setDataRegistro(String dataRegistro){this.dataRegistro = dataRegistro;}
	
	public String getValidade(){return validade;}
	public void setValidade(String validade){this.validade = validade;}
	
	public int getQuantidade(){return quantidade;}
	public void setQuantidade(int quantidade){this.quantidade = quantidade;}
	
	public Usuario getIdUsuario(){return idUsuario;}
	public void setIdUsuario(Usuario idUsuario){this.idUsuario = idUsuario;}
	
	public Produto getIdProduto(){return idProduto;}
	public void setIdProduto(Produto idProduto){this.idProduto = idProduto;}
	
	public Membro getIdMembro(){return idMembro;}
	public void setIdMembro(Membro idMembro){this.idMembro = idMembro;}
	
}