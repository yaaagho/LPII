package br.com.herbertrausch.spring.mongo;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface RegistroFinanceiroRepository  extends MongoRepository<RegistroFinanceiro, String> {

	@Query("{'usuario' :{'$ref' : 'usuario' , '$id' : ?0}}")
	List<RegistroFinanceiro> findByUsuario(String usuarioId);
	
	List<RegistroFinanceiro> findByData(String data);
	List<RegistroFinanceiro> findByDataRegistro(String dataRegistro);
}
