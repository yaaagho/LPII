package br.com.herbertrausch.spring.mongo;

import java.util.List;

import org.springframework.context.ApplicationContext;

import br.com.herbertrausch.util.SpringUtil;

public class RegistroFinanceiroService {

	private RegistroFinanceiroRepository db;
	private UsuarioRepository dbu;
	
	public RegistroFinanceiroService(){
	
		ApplicationContext context =SpringUtil.getContext();
		db =  context.getBean(RegistroFinanceiroRepository.class);
		dbu =  context.getBean(UsuarioRepository.class);
		
	}
	
	public void insert(RegistroFinanceiro r){
		Usuario u = r.getUsuario();
		dbu.save(u);
		db.save(r);
	}
	
	public List<RegistroFinanceiro> getAll(){
		
		return db.findAll();
	}
	
	public List<RegistroFinanceiro> getByData(String data){
		
		return db.findByData(data);
	}
	
	public List<RegistroFinanceiro> getByDataRegistro(String dataRegistro){
		
		return db.findByDataRegistro(dataRegistro);
	}
	
	public List<RegistroFinanceiro> getByUsuarioId(String id) {
		
		return db.findByUsuario(id);
	}

}

